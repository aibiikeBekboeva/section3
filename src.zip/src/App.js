import React from 'react';
import Three from "./modules/sec-3/Three";




const App = () => {
    return (
<div>
    <Three />
</div>
    );
};

export default App;